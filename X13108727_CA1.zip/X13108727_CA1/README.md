#Distributed Systems CA1

compile all sources
```
javac CA1/*.java
javac *.java
```
##To Run:

###Tab 1
```
tnameserv -ORBInitialPort 49000
```

###Tab 2
```
java CA1Server
```

###Tab 3
Pass two integer arguments, will print addition result
```
java CA1Client 2 3
```
